package ar.edu.centro8.ps.encriptado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EncriptadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
